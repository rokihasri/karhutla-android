# RESPON KARHUTLA - Android WebView

Android WebView untuk `https://karhutla.thegreatmonolith.com` dengan tema dan logo RESPON KARHUTLA.

## Yang sudah disiapkan

- URL utama: `https://karhutla.thegreatmonolith.com`
- Application ID / package: `com.responkarhutla.app`
- Target SDK: Android 16 / API 36
- OneSignal App ID: `aaf79362-81a9-4b1e-a1cb-27298798ca7d`
- OneSignal Android SDK 5.6.1+
- Permission notifikasi Android
- Permission lokasi untuk `navigator.geolocation` di WebView
- Upload foto: galeri + kamera
- Login/session Laravel tetap berada di WebView melalui cookie
- Push OneSignal yang ditap diarahkan ke halaman terkait di dalam WebView
- External link (WhatsApp, telepon, email, map, domain lain) dibuka dengan aplikasi yang sesuai
- Launcher icon memakai logo api RESPON KARHUTLA
- Small notification icon memakai logo api versi monokrom putih/transparan sesuai spesifikasi Android
- Splash/status/navigation bar mengikuti tema hitam-merah aplikasi

## WAJIB sebelum mengetes push Android

OneSignal Web Push dan OneSignal Android Push adalah channel yang berbeda. Di dashboard OneSignal yang sama, buka:

`Settings > Push & In-App > Google Android (FCM)`

Lalu selesaikan konfigurasi FCM Android. Tanpa kredensial FCM Android, SDK dapat terpasang tetapi push native Android tidak akan terkirim.

Setelah FCM aktif, install APK, izinkan notifikasi, lalu cek `Audience > Subscriptions` di OneSignal. Perangkat harus muncul sebagai subscription Android dan statusnya Subscribed.

## Patch server pendamping

Gunakan `karhutla-webview-server-patch.zip` yang dibuat bersama project ini. Patch tersebut membuat URL notifikasi dikirim sebagai:

- `web_url` untuk Web Push, agar browser tetap membuka halaman terkait.
- `data.deep_link` untuk aplikasi Android, agar halaman dibuka langsung di WebView tanpa dilempar ke browser eksternal.

Patch juga membuat halaman dashboard mengenali OneSignal Native SDK pada WebView, melakukan `login()`/tag role ke OneSignal, dan menyinkronkan Subscription ID Android ke fallback server yang sudah ada.

## Build lewat GitHub Actions

Upload seluruh isi folder project ini ke repository GitHub lalu buka `Actions > Build Android WebView > Run workflow`.

Artifact yang dihasilkan:

- `RESPON-KARHUTLA-debug-apk` untuk tes install.
- `RESPON-KARHUTLA-release-aab-unsigned` sebagai basis build release. Untuk Play Store, AAB harus menggunakan upload keystore milik Anda.

## Build Android Studio

Buka folder project sebagai project Android Studio. Project menggunakan Gradle 8.11.1 dan Java 17.

Catatan: file `gradlew` di project ini adalah bootstrap script ringan yang otomatis mengambil Gradle 8.11.1 pada pemakaian pertama.
