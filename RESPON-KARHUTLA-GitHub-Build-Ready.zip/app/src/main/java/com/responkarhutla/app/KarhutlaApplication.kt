package com.responkarhutla.app

import android.app.Application
import android.os.Handler
import android.os.Looper
import com.onesignal.OneSignal
import com.onesignal.debug.LogLevel
import com.onesignal.notifications.INotificationClickEvent
import com.onesignal.notifications.INotificationClickListener
import com.onesignal.notifications.IPermissionObserver
import com.onesignal.user.subscriptions.IPushSubscriptionObserver
import com.onesignal.user.subscriptions.PushSubscriptionChangedState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject

class KarhutlaApplication : Application(), IPushSubscriptionObserver, IPermissionObserver {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()

        OneSignal.Debug.logLevel = if (BuildConfig.DEBUG) LogLevel.VERBOSE else LogLevel.NONE
        OneSignal.initWithContext(this, BuildConfig.ONESIGNAL_APP_ID)

        OneSignal.Notifications.addClickListener(object : INotificationClickListener {
            override fun onClick(event: INotificationClickEvent) {
                val dataUrl = event.notification.additionalData
                    ?.optString("deep_link")
                    ?.takeIf { it.isNotBlank() }
                val targetUrl = dataUrl
                    ?: event.notification.launchURL?.takeIf { it.isNotBlank() }

                if (!targetUrl.isNullOrBlank()) {
                    val activity = MainActivity.current
                    if (activity != null) {
                        activity.openNotificationUrl(targetUrl)
                    } else {
                        DeepLinkStore.save(this@KarhutlaApplication, targetUrl)
                    }
                }
            }
        })

        OneSignal.User.pushSubscription.addObserver(this)
        OneSignal.Notifications.addPermissionObserver(this)
    }

    override fun onPushSubscriptionChange(state: PushSubscriptionChangedState) {
        notifyWebViewPushState()
    }

    override fun onNotificationPermissionChange(permission: Boolean) {
        notifyWebViewPushState()
    }

    fun requestPushPermission() {
        appScope.launch {
            OneSignal.Notifications.requestPermission(true)
            notifyWebViewPushState()
        }
    }

    fun identifyUser(externalId: String, role: String, volunteerType: String) {
        val cleanExternalId = externalId.trim()
        if (cleanExternalId.isBlank()) return

        OneSignal.login(cleanExternalId)
        OneSignal.User.addTags(
            mapOf(
                "role" to role.trim().ifBlank { "user" },
                "volunteer_type" to volunteerType.trim().ifBlank { "none" }
            )
        )
        notifyWebViewPushState()
    }

    fun logoutOneSignal() {
        OneSignal.logout()
        notifyWebViewPushState()
    }

    fun pushStateJson(): String {
        val state = JSONObject()
        state.put("supported", true)
        state.put("native", true)
        state.put("permission", OneSignal.Notifications.permission)
        state.put("canRequest", OneSignal.Notifications.canRequestPermission)
        state.put("optedIn", OneSignal.User.pushSubscription.optedIn)
        state.put("subscriptionId", OneSignal.User.pushSubscription.id ?: JSONObject.NULL)
        return state.toString()
    }

    private fun notifyWebViewPushState() {
        mainHandler.post {
            MainActivity.current?.notifyPushStateChanged()
        }
    }
}
