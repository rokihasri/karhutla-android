package com.responkarhutla.app

import android.content.Context

object DeepLinkStore {
    private const val PREFS = "karhutla_native"
    private const val KEY_PENDING_URL = "pending_push_url"

    fun save(context: Context, url: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PENDING_URL, url)
            .apply()
    }

    fun consume(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val url = prefs.getString(KEY_PENDING_URL, null)
        if (!url.isNullOrBlank()) {
            prefs.edit().remove(KEY_PENDING_URL).apply()
        }
        return url
    }
}
