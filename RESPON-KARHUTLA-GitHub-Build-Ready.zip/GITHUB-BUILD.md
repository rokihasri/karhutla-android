# Build RESPON KARHUTLA di GitHub Actions

Project ini sudah siap di-upload ke repository GitHub dan dibuild tanpa Android Studio.

## Cara build

1. Buat repository baru di GitHub.
2. Ekstrak ZIP ini.
3. Upload **semua isi folder hasil ekstrak** ke root repository. Pastikan folder `.github/workflows/` ikut ter-upload.
4. Buka tab **Actions** di repository.
5. Pilih workflow **Build RESPON KARHUTLA Android**.
6. Klik **Run workflow**.
7. Tunggu proses selesai.
8. Buka hasil workflow lalu download artifact **RESPON-KARHUTLA-debug-APK**.
9. Di dalam artifact terdapat `app-debug.apk` yang bisa langsung dipasang untuk pengujian.

Workflow juga menghasilkan `RESPON-KARHUTLA-release-AAB-unsigned`. AAB tersebut belum ditandatangani untuk publikasi Play Store. Untuk tahap upload Play Store, konfigurasi signing/keystore dapat ditambahkan kemudian tanpa mengubah fungsi WebView.

## Konfigurasi aplikasi

- Package: `com.responkarhutla.app`
- URL WebView: `https://karhutla.thegreatmonolith.com`
- Target SDK: Android API 36
- OneSignal App ID sudah tertanam pada konfigurasi aplikasi.
- Permission notifikasi, lokasi, kamera, dan akses internet sudah disiapkan.
- Tap notifikasi OneSignal membuka URL/deep-link terkait di WebView.

## Penting untuk OneSignal Android

Channel Google Android/FCM pada aplikasi OneSignal harus sudah dikonfigurasi agar push native Android dapat diterima oleh APK.
