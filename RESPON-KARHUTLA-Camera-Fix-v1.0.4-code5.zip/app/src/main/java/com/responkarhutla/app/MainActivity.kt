package com.responkarhutla.app

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.onesignal.OneSignal
import org.json.JSONObject
import java.io.File
import java.net.URI

class MainActivity : AppCompatActivity() {

    companion object {
        @Volatile
        var current: MainActivity? = null
            private set
    }

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var errorPanel: LinearLayout
    private lateinit var retryButton: Button

    private val baseUri = URI(BuildConfig.APP_URL)
    private val appHost = baseUri.host.lowercase()

    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingFileChooserParams: WebChromeClient.FileChooserParams? = null
    private var cameraOutputUri: Uri? = null

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        val origin = pendingGeoOrigin
        val callback = pendingGeoCallback
        pendingGeoOrigin = null
        pendingGeoCallback = null
        if (origin != null && callback != null) {
            callback.invoke(origin, granted, false)
        }
    }

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        pendingFileChooserParams?.let { launchFileChooser(it) }
        pendingFileChooserParams = null
    }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = if (result.resultCode == Activity.RESULT_OK) {
            collectFileUris(result.data) ?: cameraOutputUri?.let { arrayOf(it) }
        } else {
            null
        }
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
        cameraOutputUri = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        errorPanel = findViewById(R.id.errorPanel)
        retryButton = findViewById(R.id.retryButton)

        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        configureWebView()

        retryButton.setOnClickListener {
            errorPanel.visibility = android.view.View.GONE
            webView.visibility = android.view.View.VISIBLE
            webView.reload()
        }

        onBackPressedDispatcher.addCallback(this) {
            if (webView.canGoBack()) webView.goBack() else finish()
        }

        if (savedInstanceState == null) {
            webView.loadUrl(BuildConfig.APP_URL)
        } else {
            webView.restoreState(savedInstanceState)
        }

        // Android 13+ notification permission. OneSignal handles the native prompt.
        root.postDelayed({
            if (!OneSignal.Notifications.permission && OneSignal.Notifications.canRequestPermission) {
                (application as KarhutlaApplication).requestPushPermission()
            }
        }, 900)
    }

    override fun onStart() {
        super.onStart()
        current = this
    }

    override fun onResume() {
        super.onResume()
        current = this
        DeepLinkStore.consume(this)?.let { openNotificationUrl(it) }
        notifyPushStateChanged()
    }

    override fun onStop() {
        if (current === this) current = null
        super.onStop()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        pendingGeoCallback?.invoke(pendingGeoOrigin, false, false)
        pendingGeoCallback = null
        pendingGeoOrigin = null
        webView.removeJavascriptInterface("KarhutlaNative")
        webView.stopLoading()
        webView.webChromeClient = null
        webView.webViewClient = WebViewClient()
        webView.destroy()
        if (current === this) current = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.dataString?.let { openNotificationUrl(it) }
    }

    @Suppress("SetJavaScriptEnabled")
    private fun configureWebView() {
        android.webkit.CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setGeolocationEnabled(true)
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            userAgentString = "$userAgentString RESPON-KARHUTLA-Android/${BuildConfig.VERSION_NAME}"
        }

        webView.addJavascriptInterface(NativeBridge(), "KarhutlaNative")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return handleNavigation(request.url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                errorPanel.visibility = android.view.View.GONE
                webView.visibility = android.view.View.VISIBLE
                notifyPushStateChanged()
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                if (request.isForMainFrame) showConnectionError()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progressBar.progress = newProgress
                progressBar.visibility = if (newProgress in 1..99) {
                    android.view.View.VISIBLE
                } else {
                    android.view.View.GONE
                }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                val fineGranted = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
                val coarseGranted = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED

                if (fineGranted || coarseGranted) {
                    callback.invoke(origin, true, false)
                } else {
                    pendingGeoOrigin = origin
                    pendingGeoCallback = callback
                    locationPermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                }
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                this@MainActivity.fileCallback?.onReceiveValue(null)
                this@MainActivity.fileCallback = filePathCallback

                val acceptsImages = fileChooserParams.acceptTypes.isEmpty() ||
                    fileChooserParams.acceptTypes.any { it.isBlank() || it.startsWith("image/") || it == "*/*" }
                val wantsDirectCamera = acceptsImages && fileChooserParams.isCaptureEnabled

                // Respect HTML `capture` (for example: <input type="file" accept="image/*" capture="environment">).
                // Previously every image input was routed through ACTION_GET_CONTENT, so tapping the
                // web app's "Ambil Gambar Camera" button could still open Gallery first.
                if (wantsDirectCamera && ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.CAMERA
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    pendingFileChooserParams = fileChooserParams
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                } else {
                    launchFileChooser(fileChooserParams)
                }
                return true
            }
        }
    }

    private fun handleNavigation(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase().orEmpty()
        if (scheme == "http" || scheme == "https") {
            return if (uri.host?.lowercase() == appHost) {
                false
            } else {
                openExternal(uri)
                true
            }
        }

        if (scheme in setOf("tel", "mailto", "sms", "smsto", "geo", "whatsapp", "market")) {
            openExternal(uri)
            return true
        }

        if (scheme.isNotBlank()) {
            openExternal(uri)
            return true
        }

        return false
    }

    private fun openExternal(uri: Uri) {
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    fun openNotificationUrl(rawUrl: String) {
        runOnUiThread {
            val target = normalizeTargetUrl(rawUrl)
            if (target == null) return@runOnUiThread
            val uri = Uri.parse(target)
            if (uri.host?.lowercase() == appHost && (uri.scheme == "https" || uri.scheme == "http")) {
                errorPanel.visibility = android.view.View.GONE
                webView.visibility = android.view.View.VISIBLE
                webView.loadUrl(target.replaceFirst("http://", "https://"))
            } else {
                openExternal(uri)
            }
        }
    }

    fun notifyPushStateChanged() {
        if (!::webView.isInitialized) return
        val json = (application as KarhutlaApplication).pushStateJson()
        val quoted = JSONObject.quote(json)
        webView.post {
            webView.evaluateJavascript(
                "window.__karhutlaNativePushStateChanged && window.__karhutlaNativePushStateChanged($quoted);",
                null
            )
        }
    }

    private fun normalizeTargetUrl(rawUrl: String): String? {
        val value = rawUrl.trim()
        if (value.isBlank()) return null
        if (value.startsWith("/")) return BuildConfig.APP_URL.trimEnd('/') + value
        if (value.startsWith("#")) return BuildConfig.APP_URL.trimEnd('/') + "/" + value
        return value
    }

    private fun showConnectionError() {
        progressBar.visibility = android.view.View.GONE
        webView.visibility = android.view.View.GONE
        errorPanel.visibility = android.view.View.VISIBLE
    }

    private fun launchFileChooser(params: WebChromeClient.FileChooserParams) {
        val acceptTypes = params.acceptTypes.filter { it.isNotBlank() }.toTypedArray()
        val primaryType = when {
            acceptTypes.isEmpty() -> "image/*"
            acceptTypes.size == 1 -> acceptTypes.first()
            else -> "*/*"
        }

        val acceptsImages = primaryType.startsWith("image/") || primaryType == "*/*" ||
            acceptTypes.any { it.startsWith("image/") }
        val cameraGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        // If the HTML input explicitly requests capture, open the camera directly.
        // This keeps "Ambil Gambar Camera" separate from the Gallery picker.
        if (params.isCaptureEnabled && acceptsImages && cameraGranted) {
            val cameraIntent = createCameraIntent()
            if (cameraIntent != null) {
                runCatching { fileChooserLauncher.launch(cameraIntent) }
                    .onFailure {
                        fileCallback?.onReceiveValue(null)
                        fileCallback = null
                        cameraOutputUri = null
                    }
                return
            }
        }

        val contentIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = primaryType
            if (acceptTypes.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, acceptTypes)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE)
        }

        val initialIntents = mutableListOf<Intent>()
        if (acceptsImages && cameraGranted) {
            createCameraIntent()?.let(initialIntents::add)
        }

        val chooser = Intent(Intent.ACTION_CHOOSER).apply {
            putExtra(Intent.EXTRA_INTENT, contentIntent)
            putExtra(Intent.EXTRA_TITLE, "Pilih foto")
            if (initialIntents.isNotEmpty()) {
                putExtra(Intent.EXTRA_INITIAL_INTENTS, initialIntents.toTypedArray())
            }
        }

        runCatching { fileChooserLauncher.launch(chooser) }
            .onFailure {
                fileCallback?.onReceiveValue(null)
                fileCallback = null
                cameraOutputUri = null
            }
    }

    private fun createCameraIntent(): Intent? {
        val directory = File(cacheDir, "webview-camera").apply { mkdirs() }
        val file = File.createTempFile("karhutla-", ".jpg", directory)
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        cameraOutputUri = uri

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            clipData = ClipData.newRawUri("karhutla-photo", uri)
        }

        return intent.takeIf { it.resolveActivity(packageManager) != null }
    }

    private fun collectFileUris(data: Intent?): Array<Uri>? {
        if (data == null) return null
        data.data?.let { return arrayOf(it) }

        val clip = data.clipData ?: return null
        if (clip.itemCount == 0) return null
        return Array(clip.itemCount) { index -> clip.getItemAt(index).uri }
    }

    private inner class NativeBridge {
        @JavascriptInterface
        fun getPushState(): String = (application as KarhutlaApplication).pushStateJson()

        @JavascriptInterface
        fun requestPushPermission() {
            (application as KarhutlaApplication).requestPushPermission()
        }

        @JavascriptInterface
        fun identifyUser(externalId: String, role: String, volunteerType: String) {
            (application as KarhutlaApplication).identifyUser(externalId, role, volunteerType)
        }

        @JavascriptInterface
        fun logoutOneSignal() {
            (application as KarhutlaApplication).logoutOneSignal()
        }
    }
}
