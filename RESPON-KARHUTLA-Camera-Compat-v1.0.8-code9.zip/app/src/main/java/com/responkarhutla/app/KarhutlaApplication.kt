package com.responkarhutla.app

import android.app.Application
import android.os.Handler
import android.os.Looper
import com.onesignal.OneSignal
import com.onesignal.debug.LogLevel
import com.onesignal.notifications.INotificationClickEvent
import com.onesignal.notifications.INotificationClickListener
import com.onesignal.notifications.IPermissionObserver
import com.onesignal.user.subscriptions.IPushSubscriptionObserver
import com.onesignal.user.subscriptions.PushSubscriptionChangedState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

class KarhutlaApplication : Application(), IPushSubscriptionObserver, IPermissionObserver {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()

        OneSignal.Debug.logLevel = if (BuildConfig.DEBUG) LogLevel.VERBOSE else LogLevel.NONE
        OneSignal.initWithContext(this, BuildConfig.ONESIGNAL_APP_ID)

        OneSignal.Notifications.addClickListener(object : INotificationClickListener {
            override fun onClick(event: INotificationClickEvent) {
                val dataUrl = event.notification.additionalData
                    ?.optString("deep_link")
                    ?.takeIf { it.isNotBlank() }
                val targetUrl = dataUrl
                    ?: event.notification.launchURL?.takeIf { it.isNotBlank() }

                if (!targetUrl.isNullOrBlank()) {
                    val activity = MainActivity.current
                    if (activity != null) {
                        activity.openNotificationUrl(targetUrl)
                    } else {
                        DeepLinkStore.save(this@KarhutlaApplication, targetUrl)
                    }
                }
            }
        })

        OneSignal.User.pushSubscription.addObserver(this)
        OneSignal.Notifications.addPermissionObserver(this)

        // Jika izin notifikasi sudah pernah diberikan, subscription OneSignal
        // langsung dipastikan aktif setiap proses aplikasi dimulai.
        ensurePushReady(false)
    }

    override fun onPushSubscriptionChange(state: PushSubscriptionChangedState) {
        notifyWebViewPushState()
    }

    override fun onNotificationPermissionChange(permission: Boolean) {
        if (permission) {
            ensurePushReady(false)
        } else {
            notifyWebViewPushState()
        }
    }

    /**
     * Memastikan push native siap tanpa tombol aktivasi manual.
     * requestPermissionIfNeeded=true hanya dipakai ketika aplikasi pertama dibuka.
     */
    fun ensurePushReady(requestPermissionIfNeeded: Boolean = false) {
        appScope.launch {
            if (
                requestPermissionIfNeeded &&
                !OneSignal.Notifications.permission &&
                OneSignal.Notifications.canRequestPermission
            ) {
                OneSignal.Notifications.requestPermission(true)
            }

            if (OneSignal.Notifications.permission) {
                if (!OneSignal.User.pushSubscription.optedIn) {
                    OneSignal.User.pushSubscription.optIn()
                }

                // Subscription ID dapat muncul beberapa saat setelah permission/opt-in.
                // Beri kesempatan SDK menyelesaikan registrasi lalu kabarkan WebView
                // agar server segera menyimpan ID tersebut untuk fallback pengiriman.
                repeat(20) {
                    notifyWebViewPushState()
                    val id = OneSignal.User.pushSubscription.id
                    if (OneSignal.User.pushSubscription.optedIn && !id.isNullOrBlank()) {
                        return@launch
                    }
                    delay(500)
                }
            }

            notifyWebViewPushState()
        }
    }

    fun requestPushPermission() {
        ensurePushReady(true)
    }

    fun identifyUser(externalId: String, role: String, volunteerType: String) {
        val cleanExternalId = externalId.trim()
        if (cleanExternalId.isBlank()) return

        OneSignal.login(cleanExternalId)
        OneSignal.User.addTags(
            mapOf(
                "role" to role.trim().ifBlank { "user" },
                "volunteer_type" to volunteerType.trim().ifBlank { "none" }
            )
        )

        // Begitu akun relawan teridentifikasi, subscription yang sudah mendapat
        // izin langsung dipastikan aktif dan tersinkron tanpa interaksi tambahan.
        ensurePushReady(false)
    }

    fun logoutOneSignal() {
        OneSignal.logout()
        notifyWebViewPushState()
    }

    fun pushStateJson(): String {
        val subscriptionId = OneSignal.User.pushSubscription.id
        val permission = OneSignal.Notifications.permission
        val optedIn = OneSignal.User.pushSubscription.optedIn

        val state = JSONObject()
        state.put("supported", true)
        state.put("native", true)
        state.put("permission", permission)
        state.put("canRequest", OneSignal.Notifications.canRequestPermission)
        state.put("optedIn", optedIn)
        state.put("subscriptionId", subscriptionId ?: JSONObject.NULL)
        state.put("ready", permission && optedIn && !subscriptionId.isNullOrBlank())
        return state.toString()
    }

    private fun notifyWebViewPushState() {
        mainHandler.post {
            MainActivity.current?.notifyPushStateChanged()
        }
    }
}
