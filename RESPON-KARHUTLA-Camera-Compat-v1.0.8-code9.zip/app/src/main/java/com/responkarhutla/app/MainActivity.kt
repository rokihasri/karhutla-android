package com.responkarhutla.app

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.io.File
import java.net.URI

class MainActivity : AppCompatActivity() {

    companion object {
        @Volatile
        var current: MainActivity? = null
            private set
    }

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var errorPanel: LinearLayout
    private lateinit var retryButton: Button
    private lateinit var nativeSplash: LinearLayout

    private var nativeSplashStartedAt = 0L
    private var nativeSplashDismissed = false

    private val baseUri = URI(BuildConfig.APP_URL)
    private val appHost = baseUri.host.lowercase()

    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingFileChooserParams: WebChromeClient.FileChooserParams? = null
    private var pendingFileChooserMode: String? = null
    @Volatile private var requestedFileChooserMode: String? = null
    private var cameraOutputUri: Uri? = null

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        val origin = pendingGeoOrigin
        val callback = pendingGeoCallback
        pendingGeoOrigin = null
        pendingGeoCallback = null
        if (origin != null && callback != null) {
            callback.invoke(origin, granted, false)
        }
    }

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        pendingFileChooserParams?.let { launchFileChooser(it, pendingFileChooserMode) }
        pendingFileChooserParams = null
        pendingFileChooserMode = null
    }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = if (result.resultCode == Activity.RESULT_OK) {
            collectFileUris(result.data) ?: cameraOutputUri?.let { arrayOf(it) }
        } else {
            null
        }
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
        cameraOutputUri = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        errorPanel = findViewById(R.id.errorPanel)
        retryButton = findViewById(R.id.retryButton)
        nativeSplash = findViewById(R.id.nativeSplash)
        nativeSplashStartedAt = android.os.SystemClock.elapsedRealtime()

        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        configureWebView()

        retryButton.setOnClickListener {
            errorPanel.visibility = android.view.View.GONE
            webView.visibility = android.view.View.VISIBLE
            webView.reload()
        }

        onBackPressedDispatcher.addCallback(this) {
            if (webView.canGoBack()) webView.goBack() else finish()
        }

        if (savedInstanceState == null) {
            webView.loadUrl(BuildConfig.APP_URL)
        } else {
            webView.restoreState(savedInstanceState)
        }

        // Splash native meniru splash PWA web. Ia menunggu halaman pertama siap,
        // dengan minimum 1,6 detik agar transisinya tidak terasa seperti flash.
        // Timeout hanya mencegah overlay tertahan bila WebView tidak pernah memanggil onPageFinished.
        nativeSplash.postDelayed({ dismissNativeSplash(force = true) }, 7000L)

        // Minta izin sekali pada awal penggunaan. Setelah pengguna memilih Izinkan,
        // OneSignal langsung di-opt-in otomatis tanpa tombol aktivasi di dashboard.
        root.postDelayed({
            (application as KarhutlaApplication).ensurePushReady(true)
        }, 900)
    }

    override fun onStart() {
        super.onStart()
        current = this
    }

    override fun onResume() {
        super.onResume()
        current = this
        (application as KarhutlaApplication).ensurePushReady(false)
        DeepLinkStore.consume(this)?.let { openNotificationUrl(it) }
        notifyPushStateChanged()
    }

    override fun onStop() {
        if (current === this) current = null
        super.onStop()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        pendingGeoCallback?.invoke(pendingGeoOrigin, false, false)
        pendingGeoCallback = null
        pendingGeoOrigin = null
        webView.removeJavascriptInterface("KarhutlaNative")
        webView.stopLoading()
        webView.webChromeClient = null
        webView.webViewClient = WebViewClient()
        webView.destroy()
        if (current === this) current = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.dataString?.let { openNotificationUrl(it) }
    }

    @Suppress("SetJavaScriptEnabled")
    private fun configureWebView() {
        android.webkit.CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setGeolocationEnabled(true)
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            userAgentString = "$userAgentString RESPON-KARHUTLA-Android/${BuildConfig.VERSION_NAME}"
        }

        webView.addJavascriptInterface(NativeBridge(), "KarhutlaNative")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return handleNavigation(request.url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                errorPanel.visibility = android.view.View.GONE
                webView.visibility = android.view.View.VISIBLE
                dismissNativeSplash()
                (application as KarhutlaApplication).ensurePushReady(false)
                notifyPushStateChanged()
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                if (request.isForMainFrame) showConnectionError()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progressBar.progress = newProgress
                progressBar.visibility = if (newProgress in 1..99) {
                    android.view.View.VISIBLE
                } else {
                    android.view.View.GONE
                }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                val fineGranted = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
                val coarseGranted = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED

                if (fineGranted || coarseGranted) {
                    callback.invoke(origin, true, false)
                } else {
                    pendingGeoOrigin = origin
                    pendingGeoCallback = callback
                    locationPermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                }
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                this@MainActivity.fileCallback?.onReceiveValue(null)
                this@MainActivity.fileCallback = filePathCallback

                val acceptsImages = fileChooserParams.acceptTypes.isEmpty() ||
                    fileChooserParams.acceptTypes.any { it.isBlank() || it.startsWith("image/") || it == "*/*" }
                val explicitMode = requestedFileChooserMode?.lowercase()
                requestedFileChooserMode = null
                val wantsDirectCamera = acceptsImages && (
                    explicitMode == "camera" ||
                        (explicitMode != "gallery" && fileChooserParams.isCaptureEnabled)
                )

                if (wantsDirectCamera && ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.CAMERA
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    pendingFileChooserParams = fileChooserParams
                    pendingFileChooserMode = explicitMode ?: "camera"
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                } else {
                    launchFileChooser(fileChooserParams, explicitMode)
                }
                return true
            }
        }
    }

    private fun handleNavigation(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase().orEmpty()
        if (scheme == "http" || scheme == "https") {
            return if (uri.host?.lowercase() == appHost) {
                false
            } else {
                openExternal(uri)
                true
            }
        }

        if (scheme in setOf("tel", "mailto", "sms", "smsto", "geo", "whatsapp", "market")) {
            openExternal(uri)
            return true
        }

        if (scheme.isNotBlank()) {
            openExternal(uri)
            return true
        }

        return false
    }

    private fun openExternal(uri: Uri) {
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    fun openNotificationUrl(rawUrl: String) {
        runOnUiThread {
            val target = normalizeTargetUrl(rawUrl)
            if (target == null) return@runOnUiThread
            val uri = Uri.parse(target)
            if (uri.host?.lowercase() == appHost && (uri.scheme == "https" || uri.scheme == "http")) {
                errorPanel.visibility = android.view.View.GONE
                webView.visibility = android.view.View.VISIBLE
                webView.loadUrl(target.replaceFirst("http://", "https://"))
            } else {
                openExternal(uri)
            }
        }
    }

    fun notifyPushStateChanged() {
        if (!::webView.isInitialized) return
        val json = (application as KarhutlaApplication).pushStateJson()
        val quoted = JSONObject.quote(json)
        webView.post {
            webView.evaluateJavascript(
                "window.__karhutlaNativePushStateChanged && window.__karhutlaNativePushStateChanged($quoted);",
                null
            )
        }
    }

    private fun normalizeTargetUrl(rawUrl: String): String? {
        val value = rawUrl.trim()
        if (value.isBlank()) return null
        if (value.startsWith("/")) return BuildConfig.APP_URL.trimEnd('/') + value
        if (value.startsWith("#")) return BuildConfig.APP_URL.trimEnd('/') + "/" + value
        return value
    }

    private fun dismissNativeSplash(force: Boolean = false) {
        if (!::nativeSplash.isInitialized || nativeSplashDismissed) return

        val elapsed = android.os.SystemClock.elapsedRealtime() - nativeSplashStartedAt
        val delay = if (force) 0L else (1600L - elapsed).coerceAtLeast(0L)

        nativeSplash.postDelayed({
            if (nativeSplashDismissed || isFinishing || isDestroyed) return@postDelayed
            nativeSplashDismissed = true
            webView.visibility = android.view.View.VISIBLE
            nativeSplash.animate()
                .alpha(0f)
                .setDuration(240L)
                .withEndAction {
                    nativeSplash.visibility = android.view.View.GONE
                    nativeSplash.alpha = 1f
                }
                .start()
        }, delay)
    }

    private fun showConnectionError() {
        progressBar.visibility = android.view.View.GONE
        nativeSplashDismissed = true
        if (::nativeSplash.isInitialized) nativeSplash.visibility = android.view.View.GONE
        webView.visibility = android.view.View.GONE
        errorPanel.visibility = android.view.View.VISIBLE
    }

    private fun launchFileChooser(
        params: WebChromeClient.FileChooserParams,
        explicitMode: String? = null
    ) {
        val acceptTypes = params.acceptTypes.filter { it.isNotBlank() }.toTypedArray()
        val primaryType = when {
            acceptTypes.isEmpty() -> "image/*"
            acceptTypes.size == 1 -> acceptTypes.first()
            else -> "*/*"
        }

        val acceptsImages = primaryType.startsWith("image/") || primaryType == "*/*" ||
            acceptTypes.any { it.startsWith("image/") }
        val cameraGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        // Prefer the explicit mode sent by the webpage. Android WebView can report
        // isCaptureEnabled=false when capture is toggled dynamically just before click().
        val directCamera = acceptsImages && cameraGranted && (
            explicitMode == "camera" ||
                (explicitMode != "gallery" && params.isCaptureEnabled)
        )
        if (directCamera) {
            val cameraIntent = createCameraIntent()
            if (cameraIntent != null) {
                runCatching { fileChooserLauncher.launch(cameraIntent) }
                    .onFailure {
                        fileCallback?.onReceiveValue(null)
                        fileCallback = null
                        cameraOutputUri = null
                        Toast.makeText(
                            this,
                            "Kamera tidak dapat dibuka di perangkat ini.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                return
            }
        }

        val contentIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = primaryType
            if (acceptTypes.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, acceptTypes)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE)
        }

        if (explicitMode == "gallery") {
            runCatching { fileChooserLauncher.launch(contentIntent) }
                .onFailure {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = null
                    cameraOutputUri = null
                }
            return
        }

        val initialIntents = mutableListOf<Intent>()
        if (acceptsImages && cameraGranted) {
            createCameraIntent()?.let(initialIntents::add)
        }

        val chooser = Intent(Intent.ACTION_CHOOSER).apply {
            putExtra(Intent.EXTRA_INTENT, contentIntent)
            putExtra(Intent.EXTRA_TITLE, "Pilih foto")
            if (initialIntents.isNotEmpty()) {
                putExtra(Intent.EXTRA_INITIAL_INTENTS, initialIntents.toTypedArray())
            }
        }

        runCatching { fileChooserLauncher.launch(chooser) }
            .onFailure {
                fileCallback?.onReceiveValue(null)
                fileCallback = null
                cameraOutputUri = null
            }
    }

    private fun createCameraIntent(): Intent {
        val directory = File(cacheDir, "webview-camera").apply { mkdirs() }
        val file = File.createTempFile("karhutla-", ".jpg", directory)
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        cameraOutputUri = uri

        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            addFlags(flags)
            clipData = ClipData.newRawUri("karhutla-photo", uri)
        }

        // Do not gate camera launch with resolveActivity(). On Android 11+ the
        // package-visibility rules can make resolveActivity() return null even
        // though the system camera can actually handle ACTION_IMAGE_CAPTURE.
        // Grant the FileProvider URI explicitly to visible camera handlers and
        // launch the intent; ActivityNotFoundException is handled by the caller.
        packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY).forEach { info ->
            grantUriPermission(info.activityInfo.packageName, uri, flags)
        }

        return intent
    }

    private fun collectFileUris(data: Intent?): Array<Uri>? {
        if (data == null) return null
        data.data?.let { return arrayOf(it) }

        val clip = data.clipData ?: return null
        if (clip.itemCount == 0) return null
        return Array(clip.itemCount) { index -> clip.getItemAt(index).uri }
    }

    private inner class NativeBridge {
        @JavascriptInterface
        fun getPushState(): String = (application as KarhutlaApplication).pushStateJson()

        @JavascriptInterface
        fun requestPushPermission() {
            (application as KarhutlaApplication).requestPushPermission()
        }

        @JavascriptInterface
        fun ensurePushReady() {
            (application as KarhutlaApplication).ensurePushReady(false)
        }

        @JavascriptInterface
        fun setFileChooserMode(mode: String) {
            requestedFileChooserMode = when (mode.lowercase()) {
                "camera" -> "camera"
                "gallery" -> "gallery"
                else -> null
            }
        }

        @JavascriptInterface
        fun identifyUser(externalId: String, role: String, volunteerType: String) {
            (application as KarhutlaApplication).identifyUser(externalId, role, volunteerType)
        }

        @JavascriptInterface
        fun logoutOneSignal() {
            (application as KarhutlaApplication).logoutOneSignal()
        }
    }
}
